using System.Collections.Generic;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace calling_card{
    public class HomeController : Controller{

        [Route("/{First}/{Last}/{Age}/{favColor}")]
        public IActionResult Card(string First, string Last, int Age, string favColor) {
            var card = new Dictionary<string, object>();
            card["First Name"] = First;
            card["Last Name"] = Last;
            card["Age"] = Age;
            card["Favorite Color"] = favColor;
            return Json(card);
        }
    }
}